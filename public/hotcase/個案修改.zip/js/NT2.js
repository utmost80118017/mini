$(document).ready(function(){

	// NT2
	setTimeout(function(){
		NT2set();
	});
	$(window).resize(function(){
		NT2set();
	});

	function NT2set(){
		$("#day .L15").height( $("#day .L85").height() );
		$("#night .L15").height( $("#night .L85").height() );

		var h = $("#detail2 .L50").eq(0).height() > $("#detail2 .L50").eq(1).height() ? $("#detail2 .L50").eq(0).height() : $("#detail2 .L50").eq(1).height();
		//$("#detail2 .L50").height( h );
	}
	$(".menu-icon a").click(function(){
		setTimeout(function(){
			NT2set();
		},500);		
	});

	var collapse2 = true;
	$(".down > img , p.more").click(function(){
		if( collapse2 ){
			$(".down > img").attr("src", "images/NT1/collapse.png");
			$(".text .more , .text img").css("display" , "none");
			$(".down > img").animate({
				top: "-121px",
			});
			$(".text").animate({
				top: "-100px",
				height: "300px"
			});

			$(".text").css("background","rgba(136,136,136,0.7)");
			$(".closeText").css("visibility", "visible");
		}
		else{
			$(".down > img").attr("src", "images/NT1/collapse2.png");
			$(".text .more , .text img").css("display" , "block");
			$(".down > img").animate({
				top: "-21px",
			});
			$(".text").animate({
				top: 0,
				height: "200px"
			});
			$(".text").css("background","url(images/NT2/wood2.jpg) no-repeat");
			$(".text").css("background-size","cover");
			$(".closeText").css("visibility", "hidden");
		}
		collapse2 = !collapse2;
	});

	// collapseMB
	var collapse3 = true;
	$("#day .collapseMB img , #day .collapseMB p").click(function(){
		if( collapse3 ){
			$("#day .collapseMB img:first-child").attr("src", "images/NT1/collapse.png");
			$("#day .content").addClass("close");
			$("#day .collapseMB h3").css("display", "none");
		}
		else{
			$("#day .collapseMB img:first-child").attr("src", "images/NT1/collapse2.png");
			$("#day .content").removeClass("close");
			$("#day .collapseMB h3").css("display", "block");
		}
		collapse3 = !collapse3;
	});

	var collapse4 = true;
	$("#night .collapseMB img , #night .collapseMB p").click(function(){
		if( collapse4 ){
			$("#night .collapseMB img:first-child").attr("src", "images/NT1/collapse.png");
			$("#night .content").addClass("close");
			$("#night .collapseMB h3").css("display", "none");
		}
		else{
			$("#night .collapseMB img:first-child").attr("src", "images/NT1/collapse2.png");
			$("#night .content").removeClass("close");
			$("#night .collapseMB h3").css("display", "block");
		}
		collapse4 = !collapse4;
	});

	var collapse5 = true;
	$("#detail .collapseMB img , #detail .collapseMB p").click(function(){
		if( collapse5 ){
			$("#detail .collapseMB img:first-child").attr("src", "images/NT1/collapse.png");
			$("#detail .intro2").addClass("close");
			$("#detail2 .L50").addClass("close");
		}
		else{
			$("#detail .collapseMB img:first-child").attr("src", "images/NT1/collapse2.png");
			$("#detail .intro2").removeClass("close");
			$("#detail2 .L50").removeClass("close");
		}
		collapse5 = !collapse5;
	});
});