$(document).ready(function(){
	
	// NT1
	var collapse = true;
	$(".down > img , p.more").click(function(){
		if( collapse ){
			$(".down > img").attr("src", "images/NT1/collapse.png");
			$(".content .more , .content img").css("display" , "none");
			$(".down > img").animate({
				top: "-121px",
			});
			$(".content").animate({
				top: "-100px",
				height: "60px"
			});

			$(".content").css("background-color","rgba(136,136,136,0.7)");
		}
		else{
			$(".down > img").attr("src", "images/NT1/collapse2.png");
			$(".content .more , .content img").css("display" , "block");
			$(".down > img").animate({
				top: "-21px",
			});
			$(".content").animate({
				top: 0,
				height: "200px"
			});
			$(".content").css("background-color","rgba(136,136,136,1)");
		}
		collapse = !collapse;		
	});	

	// collapseMB
	var collapse2 = true;
	$("#air .collapseMB img , #air .collapseMB p").click(function(){
		if( collapse2 ){
			$("#air .collapseMB img:first-child").attr("src", "images/NT1/collapse.png");
			$("#g3Title").addClass("close");
			$("#air .collapseMB h3").css("display", "none");
		}
		else{
			$("#air .collapseMB img:first-child").attr("src", "images/NT1/collapse2.png");
			$("#g3Title").removeClass("close");
			$("#air .collapseMB h3").css("display", "block");
		}
		collapse2 = !collapse2;		
	});

	var collapse3 = true;
	$("#golden4 .collapseMB img , #golden4 .collapseMB p").click(function(){
		if( collapse3 ){
			$("#golden4 .collapseMB img:first-child").attr("src", "images/NT1/collapse.png");
			$("#g4Title").addClass("close");
			$("#golden4 .collapseMB h3").css("display", "none");
		}
		else{
			$("#golden4 .collapseMB img:first-child").attr("src", "images/NT1/collapse2.png");
			$("#g4Title").removeClass("close");
			$("#golden4 .collapseMB h3").css("display", "block");
		}
		collapse3 = !collapse3;		
	});	

	// setTimeout(function(){
	// 	setHeight();	
	// },1000);
	$(window).load(function(){
		setHeight();
		
		setTimeout(function(){
			$('.cycle').cycle({ 
			    fx:    'fade', 
			    speed:  1500 
			 });
			$('.cycle2').cycle({ 
			    fx:    'fade', 
			    speed:  1500 
			});
		});
	});
	$(window).resize(function(){
		setHeight();
	});
	function setHeight(){
		$(".L25.cycle").height( $(".L25.cycle img").height() );
		$(".L25.cycle2").height( $(".L25.cycle2 img").height() );
		$(".L33.cycle").height( $(".L33.cycle img").height() );
		$(".L50.cycle").height( $(".L50.cycle img").height() );
		$(".L66.cycle").height( $(".L66.cycle img").height() );
	}

	$(".menu-icon a").click(function(){
		setTimeout(function(){
			setHeight();
		},500);		
	});
});